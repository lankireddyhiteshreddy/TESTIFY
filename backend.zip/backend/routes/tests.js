const passport = require('passport');
const {createTest,getAllTests,getTestBasedOnId} = require('../controllers/testsController');
const express = require('express');

const router = express.Router();

//create test
router.post('/createTest',passport.authenticate('jwt',{session:false}),createTest);

//get test based on id
router.get('/getTest/:id',passport.authenticate('jwt',{session:false}),getTestBasedOnId);

//get all tests
router.get('/getAllTests',passport.authenticate('jwt',{session:false}),getAllTests);



module.exports = router;

