const bcrypt = require('bcrypt');
const crypto = require('crypto');
const transporter = require('../config/mailer');
const jwt = require('jsonwebtoken');
const passport = require('passport');
const User = require('../models/userModel');

const sendVerificationEmail = async (user, res) => {
  const verificationURL = `http://localhost:3000/api/auth/verify-email?token=${user.verificationToken}`;
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: user.email,
    subject: "Please verify your email",
    html: `
      <h2>Hello, ${user.user_name}!</h2>
      <p>Please verify your email by clicking the link below:</p>
      <a href="${verificationURL}">Verify Email</a>
    `,
  };
  try {
    await transporter.sendMail(mailOptions);
    res.json({ message: 'Verification email sent. Please verify your email.' });
  } catch (error) {
    console.error('Error sending email:', error);
    res.json({ message: 'Failed to send verification email' });
  }
};

const register = async(req,res)=>{
    const {user_name,password,email} = req.body;
    try{
        const isUserExisting = await User.findOne({where : {user_name}});
        if(isUserExisting){
          if(!isUserExisting.is_verified && isUserExisting.verificationToken){
            // Resend verification email if already registered but not verified
            return sendVerificationEmail(isUserExisting, res);
          }
          return res.json({message : "The user already exists."});
        } 
        const isEmailExisting = await User.findOne({where : {email}});
        if (isEmailExisting) {
          if (!isEmailExisting.is_verified && isEmailExisting.verificationToken) {
            // Resend verification email if email already registered but not verified
            return sendVerificationEmail(isEmailExisting, res);
        }
        return res.json({ message: 'Email is already registered , try logging in' });
      }
        const hashed = await bcrypt.hash(password,12); //used to hash password ,, the number specifies the intensity of hashing the higher the number the more time it takes for hashing

        const verificationToken = crypto.randomBytes(32).toString("hex");

        const user = await User.create({user_name,email,password:hashed,is_verified:false,verificationToken});

        return sendVerificationEmail(user,res);

    }
    catch(e){
        res.json({error : e.message});
    }
};

const verifyEmail = async (req, res) => {
  const { token } = req.query;
  try {
    const user = await User.findOne({ where: { verificationToken: token } });
    if (!user) return res.send("Invalid or expired verification token.");

    user.is_verified = true;
    user.verificationToken = null;
    await user.save();

    res.redirect("http://localhost:3001/login?verified=true");
  } catch (e) {
    res.json({ error: e.message });
  }
};

const deregister = async(req,res)=>{
    const {user_name} = req.body;
    try{
        const user = await User.findOne({where : {user_name}});

        if(!user) return res.json({message : "User not found"});

        await user.destroy();

        res.clearCookie('token');

        return res.json({message : "Deregistered successfully"});
    }
    catch(e){
        res.json({error : e.message});
    }
}

const login = async(req,res)=>{
    const {user_name,password} = req.body;
    try{
        const user = await User.findOne({where : {user_name}});
        if(!user) return res.json({message : "Invalid username or password"}); 
        const isValid = await bcrypt.compare(password,user.password);
        if(!isValid) return res.json({message : "Invalid username or password"});

        if (!user.is_verified) {
          if (user.verificationToken) {
          // Resend verification email if not verified yet
            return sendVerificationEmail(user, res);
        } 
        else return res.json({ message: "Please verify your email before logging in." });
      }

        const token = jwt.sign({id : user.user_id, name : user.user_name},process.env.JWT_SECRET,{expiresIn:'30d'});
        res.cookie('token',token,{
            httpOnly : true,
            secure : false, 
            sameSite : 'lax',
            maxAge : 30 * 24 * 60 * 60 * 1000 // 30 days in milliseconds
        });

        res.json({message : "Login successful" , user : user});
    }
    catch(e){
        res.json({error : e.message});
    }
}

const logout = async(req,res)=>{
    try{
        res.clearCookie('token');
        res.json({message : 'Logged out successfully'});
    }
    catch(e){
        res.json({error : e.message});
    }
}

const googleAuth = passport.authenticate('google', { scope: ['profile', 'email'] });

const googleCallback = (req, res, next) => {
  passport.authenticate('google', { session: false }, (err, user, info) => {
    // `info` contains messages passed from done(null, false, { message: '...' })
    console.log('Google callback error:', err);
    console.log('Google callback user:', user);
    console.log('Google callback info:', info);

    if (err) {
      const message = 'Internal server error during Google login';
      return res.redirect(`http://localhost:3001?message=${encodeURIComponent(message)}`);
    }

    if (!user) {
        const message = (info && info.message) ? info.message : 'Google login failed';
        return res.redirect(`http://localhost:3001?message=${encodeURIComponent(message)}`);
    }

    try {
      const token = jwt.sign({ id: user.user_id, name: user.user_name }, process.env.JWT_SECRET, {
        expiresIn: '30d',
      });

      res.cookie('token', token, {
      httpOnly: true,
      secure: false, // true in prod
      sameSite: 'lax',
      maxAge: 30 * 24 * 60 * 60 * 1000,
    });

    // Redirect to a frontend bridge page (handles token check)
    res.send(`
      <html>
        <head>
          <script>
            setTimeout(() => {
              window.location.href = "http://localhost:3001/oauth-success";
            }, 500);
          </script>
        </head>
        <body>
          <p>Logging in via Google... Please wait.</p>
        </body>
      </html>
    `);

    } catch (e) {
      res.json({ error: e.message });
    }
  })(req, res, next);
};

const authCheck = (req,res) => {
  const token = req.cookies.token;
  if(!token) return res.sendStatus(401);

  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) return res.sendStatus(403);
    res.status(200).json({ user: decoded }); // id, name
  });
}

module.exports = {register,login,logout,deregister,googleCallback,googleAuth,verifyEmail,authCheck};