const Test = require('../models/testsModel');

const getTestBasedOnId = async(req,res) => {
    try{
        const test = await Test.findByPk(req.params.id);
        if(!test) return res.status(404).json({message : 'Test not found'});
        res.json(test);
    } 
    catch(err){
        res.status(500).json({ message: 'Error fetching test' });
    }
}

const getAllTests = async(req,res) => {
    try{
        const tests = await Test.findAll();
        res.status(200).json(tests); // status code 200 ,, server successfully processed request
    }
    catch(err){
        console.error("Error fetching tests : ",err);
        res.status(500).json({message : "Internal server error"});
    }
}

const createTest = async(req,res) => {
    try{
        const creator_id = req.user.user_id;
        const {title, description, is_public, test_duration, answer_key_uploaded,is_complete} = req.body;

        if(!title || !test_duration){
            return res.json({message : 'Title and test duration are required'});
        }

        const newTest = await Test.create({
            creator_id,
            title,
            description,
            is_public : is_public || 0,
            test_duration,
            answer_key_uploaded,
            is_complete : is_complete || 0
        });

        res.json({message : 'Test created successfully', test : newTest});
    }
    catch(e){
        res.json({error : e.message});
    }
}



module.exports = {createTest,getAllTests,getTestBasedOnId};